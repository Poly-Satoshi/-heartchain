**Consumer Contracts Config**
