[![Build](https://github.com/none/demo/actions/workflows/maven.yml/badge.svg)](https://github.com/none/demo/actions/workflows/quality.yml)
[![Bugs](/api/project_badges/measure?project=com.example%3Ademo&metric=bugs)](/dashboard?id=com.example%3Ademo)
[![Code Smells](/api/project_badges/measure?project=com.example%3Ademo&metric=code_smells)](/dashboard?id=com.example%3Ademo)
[![Coverage](/api/project_badges/measure?project=com.example%3Ademo&metric=coverage)](/dashboard?id=com.example%3Ademo)
[![Duplicated Lines (%)](/api/project_badges/measure?project=com.example%3Ademo&metric=duplicated_lines_density)](/dashboard?id=com.example%3Ademo)
[![Lines of Code](/api/project_badges/measure?project=com.example%3Ademo&metric=ncloc)](/dashboard?id=com.example%3Ademo)
[![Maintainability Rating](/api/project_badges/measure?project=com.example%3Ademo&metric=sqale_rating)](/dashboard?id=com.example%3Ademo)
[![Quality Gate Status](/api/project_badges/measure?project=com.example%3Ademo&metric=alert_status)](/dashboard?id=com.example%3Ademo)
[![Reliability Rating](/api/project_badges/measure?project=com.example%3Ademo&metric=reliability_rating)](/dashboard?id=com.example%3Ademo)
[![Security Rating](/api/project_badges/measure?project=com.example%3Ademo&metric=security_rating)](/dashboard?id=com.example%3Ademo)
[![Technical Debt](/api/project_badges/measure?project=com.example%3Ademo&metric=sqale_index)](/dashboard?id=com.example%3Ademo)
[![Vulnerabilities](/api/project_badges/measure?project=com.example%3Ademo&metric=vulnerabilities)](/dashboard?id=com.example%3Ademo) 

# demo
